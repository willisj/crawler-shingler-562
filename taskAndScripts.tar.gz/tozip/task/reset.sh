rm -rf crawlDir
rm -rf workDir
rm -rf shingleDir

mkdir crawlDir workDir shingleDir
